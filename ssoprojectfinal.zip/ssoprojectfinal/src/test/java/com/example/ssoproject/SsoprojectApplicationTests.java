package com.example.ssoproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsoprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
